package example;

public class MethodCallSequence {
	String className;
	String classObject;
	String methodName;
	boolean ifCond;
	boolean whileCond;
}
